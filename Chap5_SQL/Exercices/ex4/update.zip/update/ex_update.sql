-- mise à jour de la table pilots

/*
Copier les commandes dans votre terminal une à une
*/

UPDATE `pilots`
SET 
`birth_date` = '1978-02-04 00:00:00',
`next_flight` = '2020-12-04 09:50:52',
`num_jobs` = 10
WHERE `name` = 'Yi';
​
UPDATE `pilots`
SET `birth_date` = '1978-10-17 00:00:00',
`next_flight` = '2020-06-11 12:00:52',
`num_jobs` = 50
WHERE `name` = 'Sophie';
​
UPDATE `pilots`
SET `birth_date` = '1990-04-04 00:00:00',
`next_flight` = '2020-05-08 12:50:52',
`num_jobs` = 10
WHERE `name` = 'Albert';
​
UPDATE `pilots`
SET `birth_date` = '1998-01-04 00:00:00',
`next_flight` = '2020-05-08 12:50:52',
`num_jobs` = 30
WHERE `name` = 'Yan';
​
UPDATE `pilots`
SET `birth_date` = '2000-01-04 00:00:00',
`next_flight` = '2020-02-04 12:50:52',
`num_jobs` = 7
WHERE `name` = 'Benoit';
​
UPDATE `pilots`
SET `birth_date` = '2000-01-04 00:00:00',
`next_flight` = '2020-12-04 12:50:52',
`num_jobs` = 13
WHERE `name` = 'Jhon';
​
UPDATE `pilots`
SET `birth_date` = '1977-01-04 00:00:00',
`next_flight` = '2020-05-04 12:50:52',
`num_jobs` = 8
WHERE `name` = 'Pierre';
​
UPDATE `pilots`
SET `birth_date` = '2001-03-04 00:00:00',
`next_flight` = '2020-04-04 07:50:52',
`num_jobs` = 30
WHERE `name` = 'Alan';
​
UPDATE `pilots`
SET `birth_date` = '1978-02-04 00:00:00',
`next_flight` = '2020-12-04 09:50:52',
`num_jobs` = 10
WHERE `name` = 'Tom';